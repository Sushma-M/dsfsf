Application.$controller("headerPageController", ["$scope", "Widgets", "Variables", function ($scope, Widgets, Variables) {
    "use strict";

}]);