Application.$controller("rightnavPageController", ["$scope", "Widgets", "Variables", function ($scope, Widgets, Variables) {
    "use strict";

}]);