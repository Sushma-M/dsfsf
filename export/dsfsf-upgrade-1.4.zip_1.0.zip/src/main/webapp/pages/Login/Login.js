Application.$controller("LoginPageController", ["$scope", "Widgets", "Variables",
    function ($scope, Widgets, Variables) {
        "use strict";
    }
    ]);

Application.$controller("loginFormController", ["$scope",
    function ($scope) {
        "use strict";
        $scope.ctrlScope = $scope;
    }
    ]);